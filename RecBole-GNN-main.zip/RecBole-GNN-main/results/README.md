## General Model Results

* [ml-1m](general/ml-1m.md)

## Sequential Model Results

* [diginetica](sequential/diginetica.md)

## Social-aware Model Results

* [lastfm](social/lastfm.md)
