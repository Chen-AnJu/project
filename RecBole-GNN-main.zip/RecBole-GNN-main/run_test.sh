#!/bin/bash


python -m pytest -v tests/test_model.py
echo "model tests finished"
