#python src/train.py --root ../../data/SelfGNN/pyg/planetoid --name cora
#python src/train.py --root ../../data/SelfGNN/pyg/planetoid --name citeseer
#python src/train.py --root ../../data/SelfGNN/pyg/planetoid --name pubmed --norms no no batch

# python src/train.py --root ../../data/SelfGNN/pyg/ --name Computers
# python src/train.py --root ../../data/SelfGNN/pyg/ --name Photo
# python src/train.py --root ../../data/SelfGNN/pyg/ --name CS
# python src/train.py --root ../../data/SelfGNN/pyg/ --name Physics


python src/train.py --root ../../data/SelfGNN/pyg --name wiki --norms no batch batch


